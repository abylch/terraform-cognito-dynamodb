import json
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table_name = 'user-table-01'

def lambda_handler(event, context):
    # Extract user information from the event
    username = event['requestContext']['authorizer']['claims']['cognito:name']
    timestamp = datetime.now().isoformat()

    # Write user information to DynamoDB
    table = dynamodb.Table(table_name)
    table.put_item(Item={'username': username, 'timestamp': timestamp})

    # Return a response
    return {
        'statusCode': 200,
        'body': json.dumps('User information written to DynamoDB')
    }



# Convert to zip --> zip lambda_function.zip lambda_function.py